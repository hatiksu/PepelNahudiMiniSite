document.addEventListener('DOMContentLoaded', function() {
    const player = document.getElementById('player');
    const playBtn = document.getElementById('playBtn');
    const progress = document.getElementById('progress');
    const currentTime = document.getElementById('currentTime');
    const duration = document.getElementById('duration');
    
    // Форматирование времени
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
    }
    
    // Обновление прогресса
    function updateProgress() {
        progress.value = (player.currentTime / player.duration) * 100 || 0;
        currentTime.textContent = formatTime(player.currentTime);
    }
    
    // Установка продолжительности
    player.addEventListener('loadedmetadata', function() {
        duration.textContent = formatTime(player.duration);
    });
    
    // Обновление времени при перемотке
    player.addEventListener('timeupdate', updateProgress);
    
    // Перемотка при изменении прогресса
    progress.addEventListener('input', function() {
        const seekTime = (progress.value / 100) * player.duration;
        player.currentTime = seekTime;
    });
    
    // Управление воспроизведением
    playBtn.addEventListener('click', function() {
        if (player.paused) {
            player.play();
            playBtn.innerHTML = '<i class="fas fa-pause"></i>';
        } else {
            player.pause();
            playBtn.innerHTML = '<i class="fas fa-play"></i>';
        }
    });
    
    // Обновление кнопки при окончании трека
    player.addEventListener('ended', function() {
        playBtn.innerHTML = '<i class="fas fa-play"></i>';
        player.currentTime = 0;
        updateProgress();
    });
});